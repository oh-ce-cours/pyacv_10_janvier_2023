def funniest():
    print("c'est vraiment super drole")
